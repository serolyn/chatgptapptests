import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.serolyn.notes',
  appName: 'SerolynNotes',
  webDir: 'web',
  bundledWebRuntime: false
};

export default config;
