# Serolyn Notes (PWA + Capacitor iOS)

Deux options, selon ton humeur et l’ego d’Apple.

## A) PWA (installation sans App Store)
1. Héberge le dossier `web/` tel quel sur n’importe quel hébergeur statique (ou teste en local avec `npx http-server web`).
2. Sur iPhone: ouvre l’URL dans Safari → bouton Partager → **Ajouter à l’écran d’accueil**. Mode standalone, offline OK.

## B) App iOS via Capacitor (App Store ou TestFlight)
Prérequis: macOS + Xcode + Node LTS + compte Apple Developer.

1. Dans ce dossier, installe les dépendances:
   ```bash
   npm install
   ```
2. Ajoute la plateforme iOS:
   ```bash
   npx cap add ios
   ```
3. Copie les assets web :
   ```bash
   npx cap copy
   ```
4. Ouvre Xcode:
   ```bash
   npx cap open ios
   ```
5. Dans Xcode: règle le **Signing & Team**, choisis un **Bundle Identifier** unique, build sur un device ou fais **Archive** pour soumettre.

Le dossier `web/` contient ton app HTML/CSS/JS. Capacitor la sert dans un `WKWebView`. Si tu modifies le web, refais `npx cap copy`.

### Notes
- Les notifications push web ne fonctionnent que pour PWA « ajoutée à l’écran d’accueil ». Pour des push natifs, intègre un plugin Capacitor.
- Les API Web limitées sur iOS (ex: WebUSB) ne sont pas dispo. Utilise des plugins Capacitor si tu as besoin de fonctionnalités natives.
